# Media Feature Extraction & Search Application

A Python desktop application for extracting visual features from videos and images using **SAM (Segment Anything Model)** and **CLIP embeddings**. Build a searchable media library and find objects by tags or visual similarity.

## Features

- **Automatic Object Segmentation**: Extract all objects from images and video frames using SAM
- **Semantic Search**: Find objects using natural language queries ("red car", "person walking")
- **Image Similarity Search**: Upload an image to find visually similar objects
- **Blurred Background Approach**: Research-backed method for better embeddings (CLIPAway, Mask-ControlNet)
- **Vector Database**: Fast similarity search with ChromaDB
- **Modern GUI**: Dark mode CustomTkinter interface with progress tracking
- **Dataset Export**: Create labeled datasets for machine learning projects
- **Batch Processing**: Handle multiple images and videos efficiently

## Installation

### Prerequisites

- Python 3.11+
- ffmpeg (for video processing)

### Setup

```bash
# Install dependencies
pip install -r requirements.txt

# For SAM model (optional, ~2.5GB download)
# Download sam_vit_h_4b8939.pth from:
# https://github.com/facebookresearch/segment-anything#model-checkpoints
# Place it in models/ directory
```

## Usage

### Run the Application

```bash
python main.py
# or
bash run.sh
```

### Using the Application

1. **Add Media Files**
   - Click "Add Images/Videos" in the sidebar
   - Select one or more files (JPG, PNG, MP4, AVI, MOV)
   - Processing starts automatically

2. **Search by Tag**
   - Click "Search by Tag" in the sidebar
   - Enter a natural language query (e.g., "blue ocean", "running dog")
   - View similarity-ranked results

3. **Search by Image**
   - Click "Search by Image"
   - Upload a reference image
   - Find visually similar objects in your library

4. **Export Dataset**
   - Click "Export Dataset"
   - Select output directory
   - Labeled segments exported for ML training

## Architecture

### Core Components

```
src/
├── models/
│   └── model_manager.py      # SAM & CLIP model loading
├── database/
│   ├── vector_db.py           # ChromaDB integration
│   └── metadata_db.py         # SQLite metadata storage
├── processing/
│   ├── segment_extractor.py   # SAM segmentation + blur
│   └── video_processor.py     # Frame extraction
└── gui/
    └── main_window.py         # CustomTkinter UI
```

### Technology Stack

- **SAM**: Segment Anything Model for object segmentation
- **CLIP (ViT-B/32)**: 512-dimensional embeddings for semantic search
- **ChromaDB**: Vector database with cosine similarity
- **SQLite**: Metadata and file tracking
- **CustomTkinter**: Modern cross-platform GUI
- **OpenCV**: Image/video processing

### Embedding Method

Uses the **blurred background approach** based on research from:
- CLIPAway (2023)
- Mask-ControlNet (2023)
- Ultralytics YOLOv8

**Key Benefits:**
- De-emphasizes background while preserving context
- Better semantic embeddings than white/black backgrounds
- 21x21 Gaussian blur kernel (research-recommended)

## Project Structure

```
.
├── main.py                    # Application entry point
├── run.sh                     # Startup script
├── requirements.txt           # Python dependencies
├── src/                       # Source code modules
│   ├── models/               # Model management
│   ├── database/             # Database integration
│   ├── processing/           # Media processing pipeline
│   └── gui/                  # User interface
├── models/                    # SAM model checkpoints (not included)
├── chroma_db/                # Vector database storage
├── extracted_segments/       # Processed segments
├── datasets/                 # Exported datasets
└── metadata.db              # SQLite database

## Performance Notes

### Demo Mode (Current)

The application runs in **CLIP-only mode** for demonstration:
- Full-image embeddings (no SAM segmentation)
- Fast processing
- No SAM model download required
- Good for testing search functionality

### Full Mode (With SAM)

To enable full object segmentation:

1. Download SAM checkpoint (~2.5GB):
   ```bash
   wget https://dl.fbaipublicfiles.com/segment_anything/sam_vit_h_4b8939.pth
   mkdir -p models
   mv sam_vit_h_4b8939.pth models/
   ```

2. Modify `main.py` to load SAM:
   ```python
   # In MediaLibraryApp._initialize()
   self.model_manager.load_sam("models/sam_vit_h_4b8939.pth")
   ```

3. Update `_process_image()` to use segment extraction

### Hardware Requirements

**Minimum (Demo Mode)**:
- CPU: 2 cores
- RAM: 4GB
- Storage: 1GB

**Recommended (Full SAM Mode)**:
- CPU: 4+ cores or GPU (CUDA support)
- RAM: 16GB
- Storage: 10GB+ (for models and segments)

## Database Schema

### SQLite Tables

**media_files**
- Stores original media file information
- Tracks processing status

**segments**
- Individual object segments
- Bounding boxes and quality scores

**tags**
- Tag vocabulary

**segment_tags**
- Many-to-many relationships with confidence scores

### ChromaDB Collections

**media_segments**
- 512-dimensional CLIP embeddings
- Cosine similarity search
- Metadata for each segment

## API Reference

### ModelManager

```python
model_manager = ModelManager()
model_manager.load_clip()  # Load CLIP model
model_manager.load_sam(checkpoint_path)  # Load SAM model
```

### VectorDatabase

```python
vector_db = VectorDatabase()
vector_db.search_by_text(query, n_results=10)
vector_db.search_by_embedding(embedding, n_results=10)
```

### SegmentExtractor

```python
extractor = SegmentExtractor(blur_kernel=21)
segments, embeddings = extractor.process_image(
    image_path, mask_generator, clip_model
)
```

## Troubleshooting

### Application won't start

- Check Python version: `python --version` (requires 3.11+)
- Verify dependencies: `pip install -r requirements.txt`
- Check logs for errors

### Search returns no results

- Ensure media files have been processed
- Check statistics in sidebar
- Try broader search queries

### Out of memory

- Reduce batch size for video processing
- Use smaller images
- Close other applications

## Future Enhancements

- **SAM 2**: Video temporal consistency
- **GPU Acceleration**: CUDA support for faster processing
- **Advanced Filtering**: Size, quality, date filters
- **Custom Labeling**: Manual dataset curation interface
- **Format Export**: COCO, YOLO, Pascal VOC formats
- **Timeline View**: Show object positions in videos

## References

- [SAM (Segment Anything)](https://github.com/facebookresearch/segment-anything)
- [CLIP (OpenAI)](https://github.com/openai/CLIP)
- [ChromaDB](https://www.trychroma.com/)
- [CustomTkinter](https://github.com/TomSchimansky/CustomTkinter)

## License

This project uses open-source technologies:
- SAM: Apache 2.0
- CLIP: MIT
- ChromaDB: Apache 2.0

## Support

For issues and questions, please check the documentation or create an issue in the repository.
