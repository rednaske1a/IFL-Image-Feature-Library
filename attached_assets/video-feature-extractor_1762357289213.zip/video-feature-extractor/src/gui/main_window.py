import customtkinter as ctk
from tkinter import filedialog, messagebox
import os
import threading
from typing import Callable, Optional
from PIL import Image, ImageTk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class MainWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("Media Feature Extraction & Search")
        self.geometry("1200x800")
        
        self.on_process_files = None
        self.on_search_by_text = None
        self.on_search_by_image = None
        self.on_export_dataset = None
        
        self._setup_ui()
    
    def _setup_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self._create_sidebar()
        self._create_main_content()
    
    def _create_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=250, corner_radius=0)
        self.sidebar.grid(row=0, column=0, rowspan=4, sticky="nsew")
        self.sidebar.grid_rowconfigure(10, weight=1)
        
        self.logo_label = ctk.CTkLabel(
            self.sidebar, 
            text="Media Library", 
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))
        
        self.subtitle_label = ctk.CTkLabel(
            self.sidebar, 
            text="SAM + CLIP Search", 
            font=ctk.CTkFont(size=12)
        )
        self.subtitle_label.grid(row=1, column=0, padx=20, pady=(0, 20))
        
        self.add_files_button = ctk.CTkButton(
            self.sidebar, 
            text="Add Images/Videos",
            command=self._on_add_files_click
        )
        self.add_files_button.grid(row=2, column=0, padx=20, pady=10)
        
        self.search_tab_button = ctk.CTkButton(
            self.sidebar,
            text="Search by Tag",
            command=lambda: self._switch_tab("search")
        )
        self.search_tab_button.grid(row=3, column=0, padx=20, pady=10)
        
        self.image_search_button = ctk.CTkButton(
            self.sidebar,
            text="Search by Image",
            command=lambda: self._switch_tab("image_search")
        )
        self.image_search_button.grid(row=4, column=0, padx=20, pady=10)
        
        self.export_button = ctk.CTkButton(
            self.sidebar,
            text="Export Dataset",
            command=self._on_export_click
        )
        self.export_button.grid(row=5, column=0, padx=20, pady=10)
        
        self.stats_frame = ctk.CTkFrame(self.sidebar)
        self.stats_frame.grid(row=9, column=0, padx=20, pady=20, sticky="ew")
        
        self.stats_label = ctk.CTkLabel(
            self.stats_frame,
            text="Statistics",
            font=ctk.CTkFont(size=14, weight="bold")
        )
        self.stats_label.pack(pady=(10, 5))
        
        self.stats_text = ctk.CTkLabel(
            self.stats_frame,
            text="Files: 0\nSegments: 0\nTags: 0",
            font=ctk.CTkFont(size=11)
        )
        self.stats_text.pack(pady=(0, 10))
    
    def _create_main_content(self):
        self.main_frame = ctk.CTkFrame(self, corner_radius=0)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)
        
        self.home_frame = ctk.CTkFrame(self.main_frame)
        self.search_frame = ctk.CTkFrame(self.main_frame)
        self.image_search_frame = ctk.CTkFrame(self.main_frame)
        
        self._create_home_tab()
        self._create_search_tab()
        self._create_image_search_tab()
        
        self._switch_tab("home")
    
    def _create_home_tab(self):
        self.home_frame.grid(row=0, column=0, sticky="nsew")
        self.home_frame.grid_rowconfigure(1, weight=1)
        self.home_frame.grid_columnconfigure(0, weight=1)
        
        welcome_label = ctk.CTkLabel(
            self.home_frame,
            text="Welcome to Media Feature Extraction",
            font=ctk.CTkFont(size=28, weight="bold")
        )
        welcome_label.grid(row=0, column=0, pady=(30, 10))
        
        info_text = ctk.CTkTextbox(self.home_frame, height=400)
        info_text.grid(row=1, column=0, padx=20, pady=20, sticky="nsew")
        info_text.insert("1.0", """
Getting Started:

1. Add Media Files
   - Click "Add Images/Videos" to import your media
   - Supports: JPG, PNG, MP4, AVI, MOV
   - Batch processing supported

2. Automatic Processing
   - SAM extracts all objects from your media
   - CLIP generates semantic embeddings
   - Features saved to vector database

3. Search by Tag
   - Type natural language queries
   - "red car", "person walking", "dog"
   - Find similar objects instantly

4. Search by Image
   - Upload a reference image
   - Find visually similar objects
   - Great for finding duplicates

5. Export Dataset
   - Create labeled datasets
   - Export segments by category
   - Ready for ML training

Features:
• Blurred background for better embeddings
• Vector similarity search with ChromaDB
• Modern dark mode interface
• Progress tracking for large batches
        """)
        info_text.configure(state="disabled")
        
        self.progress_label = ctk.CTkLabel(
            self.home_frame,
            text="Ready",
            font=ctk.CTkFont(size=12)
        )
        self.progress_label.grid(row=2, column=0, pady=10)
        
        self.progress_bar = ctk.CTkProgressBar(self.home_frame)
        self.progress_bar.grid(row=3, column=0, padx=20, pady=(0, 20), sticky="ew")
        self.progress_bar.set(0)
    
    def _create_search_tab(self):
        self.search_frame.grid(row=0, column=0, sticky="nsew")
        self.search_frame.grid_rowconfigure(1, weight=1)
        self.search_frame.grid_columnconfigure(0, weight=1)
        
        search_label = ctk.CTkLabel(
            self.search_frame,
            text="Search by Tag",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        search_label.grid(row=0, column=0, pady=20)
        
        search_input_frame = ctk.CTkFrame(self.search_frame)
        search_input_frame.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        search_input_frame.grid_columnconfigure(0, weight=1)
        
        self.search_entry = ctk.CTkEntry(
            search_input_frame,
            placeholder_text="Enter search query (e.g., 'red car', 'person walking')",
            height=40
        )
        self.search_entry.grid(row=0, column=0, padx=(20, 10), pady=20, sticky="ew")
        
        self.search_button = ctk.CTkButton(
            search_input_frame,
            text="Search",
            command=self._on_search_click,
            height=40,
            width=100
        )
        self.search_button.grid(row=0, column=1, padx=(0, 20), pady=20)
        
        self.search_results_frame = ctk.CTkScrollableFrame(self.search_frame)
        self.search_results_frame.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.search_results_frame.grid_columnconfigure(0, weight=1)
    
    def _create_image_search_tab(self):
        self.image_search_frame.grid(row=0, column=0, sticky="nsew")
        self.image_search_frame.grid_rowconfigure(1, weight=1)
        self.image_search_frame.grid_columnconfigure(0, weight=1)
        
        title_label = ctk.CTkLabel(
            self.image_search_frame,
            text="Search by Image",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        title_label.grid(row=0, column=0, pady=20)
        
        upload_button = ctk.CTkButton(
            self.image_search_frame,
            text="Upload Reference Image",
            command=self._on_upload_image_click,
            height=40
        )
        upload_button.grid(row=1, column=0, pady=20)
        
        self.image_results_frame = ctk.CTkScrollableFrame(self.image_search_frame)
        self.image_results_frame.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.image_results_frame.grid_columnconfigure(0, weight=1)
    
    def _switch_tab(self, tab_name: str):
        self.home_frame.grid_forget()
        self.search_frame.grid_forget()
        self.image_search_frame.grid_forget()
        
        if tab_name == "home":
            self.home_frame.grid(row=0, column=0, sticky="nsew")
        elif tab_name == "search":
            self.search_frame.grid(row=0, column=0, sticky="nsew")
        elif tab_name == "image_search":
            self.image_search_frame.grid(row=0, column=0, sticky="nsew")
    
    def _on_add_files_click(self):
        file_paths = filedialog.askopenfilenames(
            title="Select Images or Videos",
            filetypes=[
                ("Media files", "*.jpg *.jpeg *.png *.mp4 *.avi *.mov"),
                ("Images", "*.jpg *.jpeg *.png"),
                ("Videos", "*.mp4 *.avi *.mov"),
                ("All files", "*.*")
            ]
        )
        
        if file_paths and self.on_process_files:
            self._switch_tab("home")
            threading.Thread(
                target=self.on_process_files,
                args=(list(file_paths),),
                daemon=True
            ).start()
    
    def _on_search_click(self):
        query = self.search_entry.get().strip()
        if query and self.on_search_by_text:
            threading.Thread(
                target=self.on_search_by_text,
                args=(query,),
                daemon=True
            ).start()
    
    def _on_upload_image_click(self):
        file_path = filedialog.askopenfilename(
            title="Select Reference Image",
            filetypes=[
                ("Images", "*.jpg *.jpeg *.png"),
                ("All files", "*.*")
            ]
        )
        
        if file_path and self.on_search_by_image:
            threading.Thread(
                target=self.on_search_by_image,
                args=(file_path,),
                daemon=True
            ).start()
    
    def _on_export_click(self):
        if self.on_export_dataset:
            self.on_export_dataset()
    
    def update_progress(self, current: int, total: int, message: str = "Processing"):
        progress = current / total if total > 0 else 0
        self.progress_bar.set(progress)
        self.progress_label.configure(text=f"{message}: {current}/{total} ({progress*100:.1f}%)")
        self.update_idletasks()
    
    def set_progress_text(self, text: str):
        self.progress_label.configure(text=text)
        self.update_idletasks()
    
    def update_stats(self, files: int, segments: int, tags: int):
        self.stats_text.configure(text=f"Files: {files}\nSegments: {segments}\nTags: {tags}")
        self.update_idletasks()
    
    def show_search_results(self, results: list):
        for widget in self.search_results_frame.winfo_children():
            widget.destroy()
        
        if not results:
            no_results_label = ctk.CTkLabel(
                self.search_results_frame,
                text="No results found",
                font=ctk.CTkFont(size=16)
            )
            no_results_label.pack(pady=20)
            return
        
        for i, result in enumerate(results):
            result_frame = ctk.CTkFrame(self.search_results_frame)
            result_frame.pack(fill="x", padx=10, pady=5)
            
            result_label = ctk.CTkLabel(
                result_frame,
                text=f"{i+1}. Similarity: {result.get('distance', 0):.3f} | {result.get('metadata', {})}",
                font=ctk.CTkFont(size=12)
            )
            result_label.pack(pady=10, padx=10)
