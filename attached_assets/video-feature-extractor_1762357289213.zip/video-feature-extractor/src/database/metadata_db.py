import sqlite3
from typing import List, Dict, Optional, Tuple
import json
from datetime import datetime

class MetadataDatabase:
    def __init__(self, db_path: str = "./metadata.db"):
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        self._init_db()
    
    def _init_db(self):
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS media_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT UNIQUE NOT NULL,
                file_type TEXT NOT NULL,
                file_size INTEGER,
                width INTEGER,
                height INTEGER,
                duration REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed BOOLEAN DEFAULT 0
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS segments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                segment_id TEXT UNIQUE NOT NULL,
                media_file_id INTEGER,
                frame_number INTEGER,
                bbox_x INTEGER,
                bbox_y INTEGER,
                bbox_w INTEGER,
                bbox_h INTEGER,
                area REAL,
                iou_score REAL,
                stability_score REAL,
                segment_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (media_file_id) REFERENCES media_files(id)
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tag_name TEXT UNIQUE NOT NULL
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS segment_tags (
                segment_id INTEGER,
                tag_id INTEGER,
                confidence REAL DEFAULT 1.0,
                FOREIGN KEY (segment_id) REFERENCES segments(id),
                FOREIGN KEY (tag_id) REFERENCES tags(id),
                PRIMARY KEY (segment_id, tag_id)
            )
        ''')
        
        self.conn.commit()
    
    def add_media_file(
        self, 
        file_path: str, 
        file_type: str,
        file_size: int = 0,
        width: int = 0,
        height: int = 0,
        duration: float = 0.0
    ) -> int:
        try:
            self.cursor.execute('''
                INSERT INTO media_files (file_path, file_type, file_size, width, height, duration)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (file_path, file_type, file_size, width, height, duration))
            self.conn.commit()
            return self.cursor.lastrowid
        except sqlite3.IntegrityError:
            self.cursor.execute('SELECT id FROM media_files WHERE file_path = ?', (file_path,))
            return self.cursor.fetchone()[0]
    
    def add_segment(
        self,
        segment_id: str,
        media_file_id: int,
        frame_number: int,
        bbox: List[int],
        area: float,
        iou_score: float,
        stability_score: float,
        segment_path: str = ""
    ) -> int:
        try:
            self.cursor.execute('''
                INSERT INTO segments 
                (segment_id, media_file_id, frame_number, bbox_x, bbox_y, bbox_w, bbox_h, 
                 area, iou_score, stability_score, segment_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (segment_id, media_file_id, frame_number, *bbox, area, iou_score, stability_score, segment_path))
            self.conn.commit()
            return self.cursor.lastrowid
        except sqlite3.IntegrityError:
            self.cursor.execute('SELECT id FROM segments WHERE segment_id = ?', (segment_id,))
            return self.cursor.fetchone()[0]
    
    def add_tag(self, tag_name: str) -> int:
        try:
            self.cursor.execute('INSERT INTO tags (tag_name) VALUES (?)', (tag_name,))
            self.conn.commit()
            return self.cursor.lastrowid
        except sqlite3.IntegrityError:
            self.cursor.execute('SELECT id FROM tags WHERE tag_name = ?', (tag_name,))
            return self.cursor.fetchone()[0]
    
    def link_segment_tag(self, segment_id: int, tag_id: int, confidence: float = 1.0):
        try:
            self.cursor.execute('''
                INSERT INTO segment_tags (segment_id, tag_id, confidence)
                VALUES (?, ?, ?)
            ''', (segment_id, tag_id, confidence))
            self.conn.commit()
        except sqlite3.IntegrityError:
            pass
    
    def get_media_files(self, processed_only: bool = False) -> List[Dict]:
        if processed_only:
            self.cursor.execute('SELECT * FROM media_files WHERE processed = 1')
        else:
            self.cursor.execute('SELECT * FROM media_files')
        
        columns = [description[0] for description in self.cursor.description]
        return [dict(zip(columns, row)) for row in self.cursor.fetchall()]
    
    def get_segments_by_media_file(self, media_file_id: int) -> List[Dict]:
        self.cursor.execute('SELECT * FROM segments WHERE media_file_id = ?', (media_file_id,))
        columns = [description[0] for description in self.cursor.description]
        return [dict(zip(columns, row)) for row in self.cursor.fetchall()]
    
    def mark_media_processed(self, media_file_id: int):
        self.cursor.execute('UPDATE media_files SET processed = 1 WHERE id = ?', (media_file_id,))
        self.conn.commit()
    
    def get_stats(self) -> Dict:
        self.cursor.execute('SELECT COUNT(*) FROM media_files')
        total_files = self.cursor.fetchone()[0]
        
        self.cursor.execute('SELECT COUNT(*) FROM segments')
        total_segments = self.cursor.fetchone()[0]
        
        self.cursor.execute('SELECT COUNT(*) FROM tags')
        total_tags = self.cursor.fetchone()[0]
        
        return {
            'total_files': total_files,
            'total_segments': total_segments,
            'total_tags': total_tags
        }
    
    def close(self):
        if self.conn:
            self.conn.close()
