import chromadb
from chromadb.config import Settings
import numpy as np
from typing import List, Dict, Optional
import os

class VectorDatabase:
    def __init__(self, persist_directory: str = "./chroma_db"):
        self.persist_directory = persist_directory
        os.makedirs(persist_directory, exist_ok=True)
        
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(anonymized_telemetry=False)
        )
        
        self.collection = None
        self.collection_name = "media_segments"
    
    def create_or_get_collection(self):
        try:
            self.collection = self.client.get_collection(name=self.collection_name)
            print(f"Loaded existing collection: {self.collection_name}")
        except:
            self.collection = self.client.create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            print(f"Created new collection: {self.collection_name}")
        
        return self.collection
    
    def add_segments(
        self, 
        embeddings: np.ndarray, 
        metadatas: List[Dict], 
        ids: List[str]
    ):
        if self.collection is None:
            self.create_or_get_collection()
        
        embeddings_list = embeddings.tolist() if isinstance(embeddings, np.ndarray) else embeddings
        
        self.collection.add(
            embeddings=embeddings_list,
            metadatas=metadatas,
            ids=ids
        )
    
    def search_by_text(self, query_text: str, n_results: int = 10) -> Dict:
        if self.collection is None:
            self.create_or_get_collection()
        
        results = self.collection.query(
            query_texts=[query_text],
            n_results=n_results
        )
        
        return results
    
    def search_by_embedding(self, query_embedding: np.ndarray, n_results: int = 10) -> Dict:
        if self.collection is None:
            self.create_or_get_collection()
        
        query_embedding_list = query_embedding.tolist() if isinstance(query_embedding, np.ndarray) else query_embedding
        
        results = self.collection.query(
            query_embeddings=[query_embedding_list],
            n_results=n_results
        )
        
        return results
    
    def search_by_metadata(self, where_filter: Dict, n_results: int = 10) -> Dict:
        if self.collection is None:
            self.create_or_get_collection()
        
        results = self.collection.query(
            query_embeddings=None,
            where=where_filter,
            n_results=n_results
        )
        
        return results
    
    def get_count(self) -> int:
        if self.collection is None:
            self.create_or_get_collection()
        return self.collection.count()
    
    def delete_collection(self):
        if self.collection:
            self.client.delete_collection(name=self.collection_name)
            self.collection = None
