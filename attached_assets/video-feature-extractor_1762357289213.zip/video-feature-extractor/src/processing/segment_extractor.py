import cv2
import numpy as np
from PIL import Image
from typing import List, Dict, Optional
from tqdm import tqdm

class SegmentExtractor:
    def __init__(self, blur_kernel: int = 21):
        self.blur_kernel = blur_kernel
    
    def extract_segment_with_blurred_background(
        self, 
        mask_dict: Dict, 
        img_rgb: np.ndarray
    ) -> Optional[Dict]:
        seg_mask = mask_dict['segmentation']
        x, y, w, h = mask_dict['bbox']
        x, y, w, h = int(x), int(y), int(w), int(h)
        
        crop = img_rgb[y:y+h, x:x+w].copy()
        
        if crop.size == 0:
            return None
        
        mask_crop = seg_mask[y:y+h, x:x+w]
        
        blurred = cv2.GaussianBlur(crop, (self.blur_kernel, self.blur_kernel), 0)
        
        result = crop.copy()
        result[~mask_crop] = blurred[~mask_crop]
        
        pil_image = Image.fromarray(result.astype(np.uint8))
        
        return {
            'image': result,
            'pil_image': pil_image,
            'bbox': [x, y, w, h],
            'area': float(mask_dict['area']),
            'iou': float(mask_dict['predicted_iou']),
            'stability': float(mask_dict['stability_score'])
        }
    
    def process_image(
        self, 
        image_path: str, 
        mask_generator, 
        clip_model,
        progress_callback=None
    ) -> tuple[List[Dict], np.ndarray]:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        masks = mask_generator.generate(img_rgb)
        
        segments = []
        embeddings = []
        
        iterator = tqdm(enumerate(masks), total=len(masks), desc="Extracting segments") if progress_callback is None else enumerate(masks)
        
        for idx, mask in iterator:
            seg_data = self.extract_segment_with_blurred_background(mask, img_rgb)
            
            if seg_data is None:
                continue
            
            embedding = clip_model.encode(seg_data['pil_image'])
            
            seg_data['id'] = idx
            seg_data['source_image'] = image_path
            
            segments.append(seg_data)
            embeddings.append(embedding)
            
            if progress_callback:
                progress_callback(idx + 1, len(masks))
        
        return segments, np.array(embeddings)
