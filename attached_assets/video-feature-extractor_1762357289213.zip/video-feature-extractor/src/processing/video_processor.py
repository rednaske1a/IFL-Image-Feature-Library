import cv2
import os
import tempfile
from typing import List, Callable, Optional

class VideoProcessor:
    def __init__(self, frame_interval: int = 30):
        self.frame_interval = frame_interval
    
    def extract_frames(
        self, 
        video_path: str, 
        output_dir: Optional[str] = None,
        progress_callback: Optional[Callable] = None
    ) -> List[str]:
        if output_dir is None:
            output_dir = tempfile.mkdtemp(prefix="video_frames_")
        
        os.makedirs(output_dir, exist_ok=True)
        
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Could not open video: {video_path}")
        
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        frame_paths = []
        frame_count = 0
        saved_count = 0
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            if frame_count % self.frame_interval == 0:
                frame_filename = os.path.join(
                    output_dir, 
                    f"frame_{frame_count:06d}.jpg"
                )
                cv2.imwrite(frame_filename, frame)
                frame_paths.append(frame_filename)
                saved_count += 1
                
                if progress_callback:
                    progress_callback(frame_count, total_frames)
            
            frame_count += 1
        
        cap.release()
        
        return frame_paths
