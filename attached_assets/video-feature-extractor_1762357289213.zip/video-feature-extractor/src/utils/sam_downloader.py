import os
import requests
from tqdm import tqdm

SAM_CHECKPOINTS = {
    'vit_h': {
        'url': 'https://dl.fbaipublicfiles.com/segment-anything/sam_vit_h_4b8939.pth',
        'filename': 'sam_vit_h_4b8939.pth',
        'size_mb': 2568
    },
    'vit_l': {
        'url': 'https://dl.fbaipublicfiles.com/segment-anything/sam_vit_l_0b3195.pth',
        'filename': 'sam_vit_l_0b3195.pth',
        'size_mb': 1249
    },
    'vit_b': {
        'url': 'https://dl.fbaipublicfiles.com/segment-anything/sam_vit_b_01ec64.pth',
        'filename': 'sam_vit_b_01ec64.pth',
        'size_mb': 375
    }
}

def download_sam_checkpoint(model_type: str = 'vit_b', models_dir: str = './models'):
    if model_type not in SAM_CHECKPOINTS:
        raise ValueError(f"Invalid model type. Choose from: {list(SAM_CHECKPOINTS.keys())}")
    
    os.makedirs(models_dir, exist_ok=True)
    
    checkpoint_info = SAM_CHECKPOINTS[model_type]
    checkpoint_path = os.path.join(models_dir, checkpoint_info['filename'])
    
    if os.path.exists(checkpoint_path):
        print(f"SAM checkpoint already exists: {checkpoint_path}")
        return checkpoint_path
    
    print(f"Downloading SAM {model_type} checkpoint (~{checkpoint_info['size_mb']} MB)...")
    print(f"URL: {checkpoint_info['url']}")
    
    response = requests.get(checkpoint_info['url'], stream=True)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    
    with open(checkpoint_path, 'wb') as f:
        with tqdm(total=total_size, unit='B', unit_scale=True, desc='Downloading') as pbar:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
    
    print(f"SAM checkpoint downloaded to: {checkpoint_path}")
    return checkpoint_path
