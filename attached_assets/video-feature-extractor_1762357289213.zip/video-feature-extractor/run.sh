#!/bin/bash

echo "Starting Media Feature Extraction & Search Application..."
echo ""
echo "Note: The SAM model requires a checkpoint file (~2.5GB)."
echo "For this demo, we're using CLIP-only mode for image search."
echo ""

export DISPLAY=:0
python main.py
